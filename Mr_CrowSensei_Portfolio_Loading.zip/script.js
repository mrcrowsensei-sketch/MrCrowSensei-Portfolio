(function(){const l=document.getElementById("loader"),b=l&&l.querySelector(".loader-bar span"),p=l&&l.querySelector(".loader-percent");if(!l)return;let n=0;const t=setInterval(()=>{n+=Math.floor(Math.random()*7)+3;if(n>=100){n=100;clearInterval(t);setTimeout(()=>l.classList.add("hide"),350)}b.style.width=n+"%";p.textContent=n+"%"},65)})();
document.querySelectorAll(".faq-item").forEach(item => {
  item.addEventListener("click", () => item.classList.toggle("open"));
});

const revealItems = document.querySelectorAll(".work-card,.stat-card,.about-card,.creator-card,.faq-item");
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = "1";
      entry.target.style.transform = "translateY(0)";
      observer.unobserve(entry.target);
    }
  });
}, {threshold:.08});

revealItems.forEach(el => {
  el.style.opacity = "0";
  el.style.transform = "translateY(18px)";
  el.style.transition = "opacity .6s ease, transform .6s ease";
  observer.observe(el);
});
