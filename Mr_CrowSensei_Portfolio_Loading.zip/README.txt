# Mr CrowSensei Portfolio

Mobile-first Minecraft thumbnail designer portfolio.

## Add your thumbnails
Replace:
- images/thumb1.png
- images/thumb2.png
- images/thumb3.png
- images/thumb4.png
- images/thumb5.png
- images/thumb6.png

Keep the images at 16:9 for the best result.

## Change your Discord
Open `index.html`, find:
https://discord.com/
and replace it with your Discord invite/profile link.

## Publish from phone
Upload all files to a GitHub repository, then enable GitHub Pages in:
Settings → Pages → Deploy from branch → main → / (root)

The site is static HTML/CSS/JS, so no server is required.
